import os
import json

logger = system.util.getLogger("Logi StartupFunctions")
def get_actual_path():
#	cwd = os.getcwd()
	cwd = "C://Ignition_Instrukcje"
	return cwd
	
def check_table():
    query = "SELECT COUNT(*) FROM json;"
    try:
        record_count = system.db.runScalarQuery(query, "rotor_db")
        return record_count
    except Exception as e:
        logger.error("BLAD  bazy  danych podczas odpytywanie tabeli 'json" + str(e))
        return 0
		

def ensure_jsons_folder(base_path):
	target_path = base_path
#	target_path = os.path.join(base_path, "jsons")
	try:
		if not os.path.exists(target_path):
			os.makedirs(target_path)
			return target_path
		else:
			return target_path
	except Exception as e:
		logger.error("FOLDER: Blad podczas tworzenia folderu: " + str(e))
		return ""

def list_json_files(base_path):
	try:
		all_items = os.listdir(base_path)
		json_files = [f for f in all_items if f.lower().endswith('.json')]
		
		if len(json_files) > 0:
			return json_files
		else:
			return []
	
	except Exception as e:
		logger.error("Wystąpił błąd podczas listowania  plików: " + str(e))
		return []
		
		
def create_template(file_name, directory_path):
	full_path = os.path.join(directory_path, file_name)
	try:
	    program_number = file_name.split("_")[0]
	    program_name = file_name.split("_")[1]
	    
	    
	    x = {
	    	"Program_full_name": file_name,
	    	"Program_number": program_number,
	    	"Program_name": program_name,
	    	
	    	"steps" : [
	    		
	    	]
	    }
	    
	    with open(full_path, 'w') as f:
	    	json.dump(x,f,indent=4)
	except Exception as e:
		logger.error("Blad podczas  tworzenia szablonu " + str(file_name) + ": " + str(e))
        return None


def get_json_data(file_name,directory_path):
	full_path = os.path.join(directory_path, file_name)
	with open(full_path, 'r') as json_file:
		data = json.load(json_file)
	return data, full_path


def add_to_db(directory_path, file_names):
	for file_name in file_names:
		json_data, full_path = get_json_data(file_name, directory_path)
		
		
		if not json_data:
			continue
		
		prog_name = json_data.get("Program_name")
		prog_num = json_data.get("Program_number")
		prog_full_name = json_data.get("Program_full_name")
		check_query = "SELECT COUNT(*) FROM json WHERE Program_Number = ?"
		
		try:
			record_count = system.db.runScalarPrepQuery(check_query, [prog_num], "rotor_db")
			if record_count == 0:
				insert_query = """
				    INSERT INTO json (File_Name, Program_Name, Program_Number, Path, FolderPath) 
				    VALUES (?, ?, ?, ?, ?)
				"""
				args = [prog_full_name, prog_name, prog_num, full_path, directory_path]
				system.db.runPrepUpdate(insert_query, args, "rotor_db")
			else:
				pass
		except Exception as e:
			logger.error(str(e))
		
		
		



def add_jsons_to_db(file_name, program_name, program_number, path):
    query = "INSERT INTO json (File_Name, Program_Name, Program_Number, Path) VALUES (?, ?, ?, ?)"
    args = [file_name, directory_path]
    try:
        row_affected = system.db.runPrepUpdate(query, args, "rotor_db")
        logger.info("ZAPISANO W BAZIE: " + file_name) 
    except Exception as e:
        logger.error("BLAD podczas zapisu do bazy pliku " + str(file_name) + ": " + str(e))
        return False
		
def clear_json_table():
    logger = system.util.getLogger("Logi StartupFunctions")
    
    query = "DELETE FROM json"
    
    try:
        rows_deleted = system.db.runUpdateQuery(query, "rotor_db")
        return True
        
    except Exception as e:
        return False
		
		
		
		
		
		