def get_folder_path():
	query = "SELECT FolderPath FROM json LIMIT 1;"
	try:
		path = system.db.runScalarQuery(query, "rotor_db")
		return path
	except Exceptions as e:
		print(e)
