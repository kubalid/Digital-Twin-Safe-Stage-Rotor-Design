def isShutdownPrevented(event):
	