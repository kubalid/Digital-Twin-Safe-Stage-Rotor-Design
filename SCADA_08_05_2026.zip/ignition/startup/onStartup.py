def onStartup():
	file_list = ["1_Program.json","2_Program.json","3_Program.json","4_Program.json","5_Program.json"]
	number_list = ["1","2","3","4","5"]
	logger = system.util.getLogger("Logi")
	
	actual_path = StartupFunctions.get_actual_path()
	logger.info(actual_path)
	
	jsons_path = StartupFunctions.ensure_jsons_folder(actual_path)
	
	json_files = StartupFunctions.list_json_files(jsons_path)
	logger.info("liczba   jsonow  " + str(len(json_files)))
	#Create_template musi zwracaćdane dodawane do jsona [tablica tablic] [json1[file_name,program_name,program_number,path],json2[.....]
#	if len(json_files) == 0:
#		for file_name in file_list:
#			StartupFunctions.create_template(file_name, jsons_path)
	if len(json_files) < 5:
		for f in file_list:
			if f not in json_files:
				StartupFunctions.create_template(f, jsons_path)
	
	
	
				
	json_files = StartupFunctions.list_json_files(jsons_path)
	logger.info(str(json_files))
	
	StartupFunctions.add_to_db(jsons_path, json_files)
	
		
			
			
			
			
			
		
		

		
		
		

     
	
	
	
	
	
	
	