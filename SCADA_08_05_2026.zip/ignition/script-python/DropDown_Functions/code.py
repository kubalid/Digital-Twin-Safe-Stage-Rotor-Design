import os
import system


logger = system.util.getLogger("Logi StartupFunctions")

def get_folder_path():
	query = "SELECT FolderPath FROM json LIMIT 1;"
	try:
		path = system.db.runScalarQuery(query, "rotor_db")
		return path
	except Exception as e:
		print(e)

def getProgramsDataset():
	
	folder_path = get_folder_path()
	
	headers = ["Value", "Label"]
	data_rows = []
    
	all_items = os.listdir(folder_path)
	json_files = [f for f in all_items if f.lower().endswith('.json')]
	index = 0 
	for file_name in json_files:
		full_file_path = os.path.join(folder_path, file_name)
		try:
			json_string = system.file.readFileAsString(full_file_path)
			data = system.util.jsonDecode(json_string)
			if data is None:
				continue
            
			if isinstance(data, dict):
				program_name = data.get("Program_full_name", "Brak klucza 'Program_full_name'")
				data_rows.append([index, program_name])
				index += 1
                
			elif isinstance(data, list):
				for item in data:
					program_name = item.get("Program_full_name", "Brak klucza 'Program_full_name'")
					data_rows.append([index, program_name])
					index += 1
                    
		except Exception, e:
			print "  -> Błąd odczytu:", e
            

	return system.dataset.toDataSet(headers, data_rows)